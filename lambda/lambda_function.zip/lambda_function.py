def my_handler(event, context):
    message = 'Hello' 
    return { 
        'message' : message
    }  